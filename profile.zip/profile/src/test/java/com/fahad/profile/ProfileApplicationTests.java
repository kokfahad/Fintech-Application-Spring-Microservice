package com.fahad.profile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
